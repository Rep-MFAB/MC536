export class Consulta {
  constructor(
    public crm: number = 0,
    public cpf: number = 0,
    public hora_da_consulta: number = 0,
    public sala: number = 0,
    public data_da_consulta : number = 0
  ){}
}
