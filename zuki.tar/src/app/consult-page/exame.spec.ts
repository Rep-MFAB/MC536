import { Exame } from './exame';

describe('Exame', () => {
  it('should create an instance', () => {
    expect(new Exame()).toBeTruthy();
  });
});
