import { Cirurgia } from './cirurgia';

describe('Cirurgia', () => {
  it('should create an instance', () => {
    expect(new Cirurgia()).toBeTruthy();
  });
});
