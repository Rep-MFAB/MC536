import { Consulta } from './consulta';

describe('Consulta', () => {
  it('should create an instance', () => {
    expect(new Consulta()).toBeTruthy();
  });
});
