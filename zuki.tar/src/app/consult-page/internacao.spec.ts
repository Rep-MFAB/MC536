import { Internacao } from './internacao';

describe('Internacao', () => {
  it('should create an instance', () => {
    expect(new Internacao()).toBeTruthy();
  });
});
