export class Atendimentops {
  constructor(
    public protocolo_atendimento: number = 0,
    public data_atendimento: number = 0,
    public tipo_de_socorro: string = "",
    public cpf: string = ""
  ){}
}
