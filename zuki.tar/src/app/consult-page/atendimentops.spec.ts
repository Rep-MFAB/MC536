import { Atendimentops } from './atendimentops';

describe('Atendimentops', () => {
  it('should create an instance', () => {
    expect(new Atendimentops()).toBeTruthy();
  });
});
