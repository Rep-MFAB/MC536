export class Internacao {
  constructor(
    public protocolo: number,
    public quarto: number,
    public datain: number,
    public dataout: number,
    public leito: number
  ){}
}
