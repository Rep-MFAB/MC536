export class Cirurgia {
  constructor(
    public protocolo_cirurgia: number = 0,
    public hora_da_cirurgia: number = "",
    public data_da_cirurgia: string = "",
    public tipo_da_cirurgia: string = "",
    public cpf: number = 0,
    public crm: number = 0
  ){}
}
