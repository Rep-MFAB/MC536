import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consult-page',
  templateUrl: './consult-page.component.html',
  styleUrls: ['./consult-page.component.css']
})
export class ConsultPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
