export class Medico {
  constructor(
    public crm: number,
    public tel: number,
    public email: string,
    public nome: string,
    public cpf: number,
    public especializacao: string,
    public datanasc: number
  ){}
}
