export class Exame {
  constructor(
    public protocolo: number,
    public data: number,
    public hora: number,
    public tipo: string,
    public resultado: string
  ){}
}
